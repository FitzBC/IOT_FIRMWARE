#!/bin/sh

/etc/sh/acs_scan.sh wlan0
/etc/sh/acs_scan.sh wlan2
