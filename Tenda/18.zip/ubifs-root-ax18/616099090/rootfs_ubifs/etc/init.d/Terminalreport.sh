#!/bin/sh

case "$1" in
	start)
		echo "Starting Terminalreport..."
		/bin/Terminalreport &
		exit 0
		;;

	*)
		echo "$0: unrecognized option $1"
		exit 1
		;;

esac

