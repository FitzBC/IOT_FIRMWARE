<?xml version="1.0" encoding="UTF-8"?>
<settings>
<client ip="121.35.180.205" lat="22.5333" lon="114.1333" isp="China Telecom" isprating="3.7" rating="0" ispdlavg="0" ispulavg="0" loggedin="0" country="CN" />
<server-config threadcount="4" ignoreids="1525,1716,1758,1762,1816,1834,1839,1840,1850,1854,1859,1860,1861,1871,1873,1875,1880,1902,1913,3280,3448,3695,3696,3697,3698,3699,3725,3726,3727,3728,3729,3730,3731,3733,3788,4140,4533,5085,5086,5087,5894,6130,6285,6397,6398,6412,7326,7334,7529,8591,9123,9466,9816,10221,10226,10556,10557,10558,10561,10562,10563,10564,10565,10566,10567,10901,10923,11201,11736,11737,11792,12688,12689,12861,12862,12863,13362,14209,14445,14446,14448,14804,14805,14806,14807,14808,14809,14810,14811,14812,14813,14814,14880,14881,14882,14883,14884,14908,14909,14910,14911,14946,14981,14982,14983,14984,14985,15012,15030,15034,15035,15036,15037,15079,15080,15081,15115,15181,15182,15262,15316,15359,15668,15845,15949,15950,15951,15952,15953,15954,15955,15956,15957,16030,16136,16275,16340,949,5249" notonmap="16148,17455,13544,3378,4247,9644,12549,6051,4231,12776,4139,14771,5237,17310,6385,15929,11076,5718,4810,16125,15715,3979,3088,9984,4674,988,9598,17034,5834,2151,8455,8009,6814,17040,4745,6616,2705,5681,6866,11424,3170,6563,4984,10366,6307,11266,6053,6827,10045,6562,15252,12363,8367,15418,16836,17091,10025,13185,17037,2724,4084,10469,2557,17036,1823,5045,5950,6389,4730,13152,9100,6083,17097,10323,1119,4426,3777,3704,3326,17350,10465,2721,3256,10657,6118,10258,8881,12506,5211,13040,9913,15850,13291,11365,16534,9147,13953,5651,6440,3149,13061,10586,4541,14678,17338,17160,4166,7103,15370,15213,3497,5284,7396,2706,16982,12260,11547,6151,10026,8066,5911,11123,10408,6115,4078,7352,17305,15815,10262,16152,11965,2822,6522,5326,15569,5121,5447,9264,6010,7743,6446,16747,8478,16549,2518,6195,16563,5477,6578,12212,9332,8040,14521,17312,12974,16678,17270,11465,10053,2372,8223,11181,8068,8497,17300,4297,6394,3077,17395,6225,15263,16326,12791,8836,8218,16781,17402,10676,11977,10265,1688,16676,16476,17001,15586,10176,9084,12777,6070,15904,3744,16161,6635,7567,4768,17335,11329,6057,15567,6029,5904,8879,4246,15240,9281,6433,16702,16918,16141,16325,7635,2796,5708,6101,16252,13667,17393,6689,1993,8825,12723,16754,11675,3667,5502,10264,8211,3997,16949,5623,13421,9641,14476,10703,4792,6737,6049,16067,4111,9836,9709,4089,4290,11608,16951,826,13030,3025,7537,3860,16753,2565,4049,17394,13454,9911,5210,4962,2485,13898,16653,2978,9035,5818,5652,10097,7440,6375,7617,6973,15808,2214,11348,3676,11842,5463,9508,14671,16505,6485,2605,10050,11750,7193,5919,15809,12012,15912,17311,16681,16730,2254,15199,12263,7323,4667,13873,4791,16818,10261,12536,3287,11250,1781,12652,12927,10116,8863,12557,16251,10591,6030,10546,7170,16910,16686,16888,9493,6583,6903,8109,9933,12961,7296,2268,17428,2221,12417,4168,17413,15326,7983,9560,4987,8738,3964,7192,16190,8404,13628,16157,15251,15831,1749,9540,6679,10667,10156,16785,8339,6286,15416,9942,16510,4317,7640,13583,6855,6722,7244,5303,5861,10269,7456,6047,3883,13516,6248,17249,16735,5905,9916,3864,7048,11953,12407,13655,5296,3165,13653,15853,9887,4774,1182,16613,15783,16331,2442,6074,12176,3501,16683,9384,8706,12823,16615,6559,17053,2222,3529,9951,13635,9716,6257,868,17133,16089,4632,16744,16139,7340,10614,5727,8882,11876,12497,8956,15028,15797,15992,10952,9334,12252,8906,9089,17013,7382,10444,16007,10839,10801,8631,7236,13108,9570,15630,10193,10549,13167,12384,10020,6936,4183,10194,4520,4757,13926,3385,15648,9450,12215,6031,15781,16684,6782,16122,10471,6838,11702,4938,2327,8623,11703,7429,8624,12596,4505,5334,9118,5528,8493,15131,7687,4939,4947,16991,2591,3841,12585,7076,6597,16985,11709,8628,16992,3458,4406,6321,16861,15718,9096,5020,4728,4588,17049,13242,7810,4773,12204,16993,8002,12589,12600,11712,16989,16947,3842,2189,10101,16235,6767,7198,2428,11194,2552,11430,7215,9174,8156,16416,9594,10322,9725,12694,5415,3870,6403,12775,8659,9584,12843,9049,16124,10637,6746,6454,7605,10800,7950,15224,16092,17208,15747,8978,4883,15886,5060,13384,16256,12977,15193,6749,4491,12951,10196,16487,5311,7128,9995,3984,10631,11322,17486,6261,5329,13418,6683,12718,9965,16916,14062,14059,9724,16792,16221,15872,6383,12210,7805,1169,12443,7662,6521,11823,5394,5609,7115,15492,9830,16628,6283,5431,8797,9556,1826,10560,2583,6243,2649,15535,5376,11562,9591,6455,11413,16462,7231,17078,11361,10346,10481,6432,11468,11014,15530,4706,7784,15493,11558,9966,17344,10204,8448,6756,16557,10491,14626,9282,12973,6582,15611,4182,13280,1788,2256,16460,11248,13093,9509,10574,10798,3281,8760,12409,13459,15810,10599,9603,17248,8158,9331,12635,11342,2515,15324,12473,11411,16749,8491,9668,7295,824,4836,12208,11846,16914,12632,12459,3132,15278,6537,4306,2617,7698,12942,13612,6858,6213,3917,11683,13116,4348,10327,11850,4956,17318,12895,8875,1883,7311,9575,4235,7556,5168,10769,5304,5048,10518,13258,11435,8674,8291,12616,8229,11255,8288,11102,13222,13457,8548,6370,15560,12984,12470,15854,13569,17238,13077,16348,9021,13398,12737,7804,7582,6612,11118,8874,11033,12909,10239,282,17045,7410,5248,7680,13954,5356,9856,11052,16039,11172,5963,2194,4506,2821,6110,11319,5909,12273,8261,9756,11224,16390,12207,7292,12197,7397,4958,6434,12006,7106,11815,15344,12233,13957,2157,15930,13874,13084,9104,6535,11960,5272,8370,9344,2952,15254,13566,10454,8927,15175,16082,16648,7059,11840,15443,9451,9218,16740,11735,12556,13582,17169,15983,12105,8719,16579,11314,11996,17420,15958,9266,12332,17438,13029,3825,11499,7763,11175,12814,11211,9339,6773,15071,11567,17009,15933,13982,17284,6533,11488,12322,15147,16896,15798,9000,7690,12996,16680,12668,3367,15532,9227,10990,7254,1817,6246,10312,11310,12088,12109,5889,13780,16373,16660,16203,10333,6155,1714,6200,8749,16371,16721,2171,13278,16208,17109,9749,12732,8793,13065,8017,16060,16426,16041,6355,3505,5666,11767,14329,2582,2173,10893,16429,15899,13474,13425,7318,8894,13921,5868,1818,6093,6003,12373,8453,900,16195,5181,6825,4336,16640,234,5074,4051,6359,12651,5539,16805,9974,721,8345,13676,10179,9345,8855,7393,12440,12932,16592,13057,2169,4052" forcepingid="" preferredserverid=""/>
<licensekey>f7a45ced624d3a70-1df5b7cd427370f7-b91ee21d6cb22d7b</licensekey>
<customer>speedtest</customer>
<odometer start="19601573884" rate="12"/>
<times dl1="5000000" dl2="35000000" dl3="800000000" ul1="1000000" ul2="8000000" ul3="35000000"/>
<download testlength="10" initialtest="250K" mintestsize="250K" threadsperurl="4"/>
<upload testlength="10" ratio="5" initialtest="0" mintestsize="32K" threads="2" maxchunksize="512K" maxchunkcount="50" threadsperurl="4"/>
<latency testlength="10" waittime="50" timeout="20"/>
<socket-download testlength="15" initialthreads="4" minthreads="4" maxthreads="32" threadratio="750K" maxsamplesize="5000000" minsamplesize="32000" startsamplesize="1000000" startbuffersize="1" bufferlength="5000" packetlength="1000" readbuffer="65536"/>
<socket-upload testlength="15" initialthreads="dyn:tcpulthreads" minthreads="dyn:tcpulthreads" maxthreads="32" threadratio="750K" maxsamplesize="1000000" minsamplesize="32000" startsamplesize="100000" startbuffersize="2" bufferlength="1000" packetlength="1000" disabled="false"/>
<socket-latency testlength="10" waittime="50" timeout="20"/>
<conditions>
<cond name="tcpulthreads" download="+100000" value="8" />
<cond name="tcpulthreads" download="+10000" value="4" />
<cond name="tcpulthreads" value="2" />
</conditions><interface template="mbps" colortcp="0" />
<translation lang="xml" >
<text id="rateyourisp">Rate Your ISP</text>
<text id="copy">COPY IP</text>
<text id="long-kbps">kilobits</text>
<text id="long-Mbps">megabits</text>
<text id="newserver">NEW SERVER</text>
<text id="testagain">TEST AGAIN</text>
<text id="uploadspeed">UPLOAD SPEED</text>
<text id="downloadspeed">DOWNLOAD SPEED</text>
<text id="kbps">kbps</text>
<text id="Mbps">Mbps</text>
<text id="begintest">BEGIN TEST</text>
<text id="startclosest">START TEST TO RECOMMENDED SERVER</text>
<text id="long-MB/s">megabytes</text>
<text id="long-kB/s">kilobytes</text>
<text id="kB/s">kB/s</text>
<text id="MB/s">MB/s</text>
<text id="mbps">Mbps</text>
<text id="ratinghelp">How happy are you with your current Internet service provider?</text>
<text id="rating1">Very unhappy</text>
<text id="rating2">Unhappy</text>
<text id="rating3">Neutral</text>
<text id="rating4">Happy</text>
<text id="rating5">Very happy</text>
<text id="speedwavebegin">YOUR RESULT WILL BECOME PART OF A SPEED WAVE</text>
<text id="ping">PING</text>
<text id="hostedby">Hosted by</text>
<text id="counterdescription">TOTAL TESTS
TO DATE</text>
<text id="copied">COPIED</text>
<text id="autostartdesc">AUTO STARTING SPEED TEST IN</text>
<text id="seconds">SECONDS</text>
<text id="second">SECOND</text>
<text id="error">ERROR</text>
<text id="tryagain">Try Again</text>
<text id="share-wavetitle">START A SPEED WAVE</text>
<text id="share-namewave">Speed Wave Name</text>
<text id="share-waveresults">Your result is now part of the Speed Wave!</text>
<text id="compare-yourtest">Your Result</text>
<text id="survey-surveytitle">Help Us Understand Broadband Costs</text>
<text id="survey-downloadpackage">Download Package</text>
<text id="survey-uploadpackage">Upload Package</text>
<text id="survey-howmuch">How much do you pay?</text>
<text id="survey-includes">Includes:</text>
<text id="survey-postalcode">Is this your postal code?</text>
<text id="survey-submit">SUBMIT</text>
<text id="share-accounttitle">GET A FREE OOKLA SPEEDTEST ACCOUNT</text>
<text id="share-accountdescription">Being logged in would allow you to start a Speed Wave here!
Registration is free and only requires a valid email address.</text>
<text id="share-emailaddress">Your Email Address</text>
<text id="share-twitterurl">https://twitter.com/share?text=Check%20out%20my%20%40Ookla%20Speedtest%20result!%20What%27s%20your%20speed%3F&amp;url=http%3A%2F%2Fwww.speedtest.net%2Fmy-result%2F{RESULTID}&amp;related=ookla%3ACreators%20of%20Ookla%20Speedtest&amp;hashtags=speedtest</text>
<text id="share-facebookurl">https://www.facebook.com/dialog/feed?app_id=581657151866321&amp;link=http://www.speedtest.net/my-result/{RESULTID}&amp;description=This%20is%20my%20Ookla%20Speedtest%20result.%20Compare%20your%20speed%20to%20mine!&amp;redirect_uri=http://www.speedtest.net&amp;name=Check%20out%20my%20Ookla%20Speedtest%20results.%20What%27s%20your%20speed%3F</text>
<text id="share-viewwave">VIEW SPEED WAVE</text>
<text id="share-createwave">CREATE</text>
<text id="survey-speed">Speed</text>
<text id="survey-phone">Phone</text>
<text id="survey-tv">TV</text>
<text id="survey-package">What speeds do you pay for?</text>
<text id="survey-thanks">Thanks for participating in the survey!</text>
<text id="selectingbestserver">SELECTING BEST SERVER BASED ON PING</text>
<text id="compare-myresults">MY RESULTS</text>
<text id="share-createaccount">CREATE</text>
<text id="begintest-preferred">YOUR PREFERRED SERVER</text>
<text id="begintest-ping">RECOMMENDED SERVER</text>
<text id="connecting">CONNECTING</text>
<text id="share-copy">COPY</text>
<text id="endtest-share-button">SHARE THIS RESULT</text>
<text id="endtest-compare-button">COMPARE 
YOUR RESULT</text>
<text id="endtest-contribute-button">CONTRIBUTE
TO NET INDEX</text>
<text id="close">CLOSE</text>
<text id="survey-retake">RETAKE THE
SURVEY</text>
<text id="share-link">IMAGE</text>
<text id="share-forum">FORUM</text>
<text id="share-wavedescription">Use this test result to begin your own Speed Wave!</text>
<text id="pcmagmessage">Fastest ISPs</text>
<text id="panel0">wave</text>
<text id="panel1">share</text>
<text id="panel2">link:{LANG_CODE}/results.php?source=compare</text>
<text id="panel3">contribute</text>
<text id="bitspersecond">bits per second</text>
<text id="endtest">standard</text>
<text id="lang">en</text>
<text id="share-pinteresturl">http://pinterest.com/pin/create/button/?url=http%3A%2F%2Fwww.speedtest.net%2F&amp;media=http%3A%2F%2Fspeedtest.net%2Fresult%2F{RESULTID}.png&amp;description=Check%20out%20my%20result%20from%20Ookla%20Speedtest!</text>
<text id="panelsuffix"></text>
<text id="survey-nextbtn">Continue</text>
<text id="survey-editbtn">EDIT</text>
<text id="survey-download">Download</text>
<text id="survey-download-validate">Download:</text>
<text id="survey-upload">Upload</text>
<text id="survey-upload-validate">Upload:</text>
<text id="survey-connectiontype">Connection Type?</text>
<text id="survey-q1label1">Home</text>
<text id="survey-q1label2">Business</text>
<text id="survey-q1label3">School</text>
<text id="survey-q1label4">Public Wi-Fi</text>
<text id="survey-q1label5">Other</text>
<text id="survey-ispconf">My ISP is:</text>
<text id="survey-q2label1">Yes</text>
<text id="survey-q2label2">Wrong</text>
<text id="survey-q3label1">Yes</text>
<text id="survey-q3label2">Wrong</text>
<text id="survey-postalcode-input">Please enter your postal code</text>
<text id="survey-labelispinput">Please enter your ISP name</text>
<text id="survey-okbtn">OK</text>
<text id="survey-validationUploadline1">Please check your upload speed.
  This seems faster than expected.</text>
<text id="survey-validationAmountline1">Please check the amount entered.
    This seems higher than expected.</text>
<text id="survey-validationDownloadline1">Please check your Download speed.
  This seems faster than expected.</text>
<text id="share-web">WEB</text>
<text id="share-html">EMBED</text>
<text id="endtest-contribute-are-you-on">Are you on</text>
<text id="endtest-contribute-take-survey">Take our Broadband Internet Survey!</text>
<text id="endtest-test-again">TEST AGAIN</text>
<text id="endtest-compare">COMPARE</text>
</translation>

</settings>