
//输出目录
exports.dist = "./";

exports.config = {
    "tendawifi.com": "tendawifi.com"
};