#!/bin/sh
# utf-8 coding

cfm set wan1.connecttype 0
cfm post multiWAN 12 1 0 0
