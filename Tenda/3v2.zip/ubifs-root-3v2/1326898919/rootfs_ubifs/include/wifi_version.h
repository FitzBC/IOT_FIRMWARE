#ifndef __WIFI_VERSION_INCLUDE_H__ 
#define __WIFI_VERSION_INCLUDE_H__ 
#define _WIFI_SVN_REVISION_ "6846"
#define _WIFI_SVN_LAST_CHANGED_REV_ "6824"
#define _WIFI_SVN_URL_ "http://192.168.100.233:18080/svn/UGWV6.0_T/SourceCodes/Branches/AX3V2.0/Trunk_SVN5638/develop/cbb/wifi"
#define _WIFI_SVN_LAST_CHANGED_AUTHOR_ "Wanggang"
#define _WIFI_SVN_LAST_CHANGED_DATE_ "2021-04-03 11:16:09"
#define _WIFI_GIT_VERSION_ ""
#define _WIFI_BUILD_TIME_ "2021-04-08 16:46:48"
#define _WIFI_BUILD_USER_ "root"
#endif
